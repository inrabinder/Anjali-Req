package com.yash.ytdms.factory;

import com.yash.ytdms.dao.TestDAO;
import com.yash.ytdms.daoimpl.TestDAOImpl;
import com.yash.ytdms.service.TestService;
import com.yash.ytdms.serviceimpl.TestServiceImpl;
/**
 * This object factory is used to get the Implementation object based on reference type
 * You need to copy paste the if block and change the Reference type as per your requirement. 
 * If condition is met successfully, return the implementation object. 
 * @author samay.jain
 *
 */
public class ObjectFactory {

	public static Object getObject(Class refClassName) {
		
		if(refClassName == TestDAO.class) {
			return (Object) new TestDAOImpl();
		}
		
		if(refClassName == TestService.class) {
			return (Object) new TestServiceImpl();
		}
		return null;
	}

}
