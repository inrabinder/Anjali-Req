package com.yash.ytdms.factory;

import com.yash.ytdms.dao.GroupDAO;

import com.yash.ytdms.daoimpl.GroupDAOImpl;

import com.yash.ytdms.service.GroupService;

import com.yash.ytdms.serviceimpl.GroupServiceImpl;

public class GroupObjectFactory {

	public static Object getObject(Class refClassName) {

		if (refClassName == GroupDAO.class) {
			return (Object) new GroupDAOImpl();
		}

		if (refClassName == GroupService.class) {
			return (Object) new GroupServiceImpl();
		}
		return null;
	}

}
