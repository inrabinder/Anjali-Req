package com.yash.ytdms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.yash.ytdms.dao.UserDAO;
import com.yash.ytdms.domain.User;
import com.yash.ytdms.util.JNDIUtil;

public class UserDAOImpl extends JNDIUtil implements UserDAO {

	@Override
	public void save(User user) {
		
		String sql="INSERT INTO users(NAME,emailId,PASSWORD,groupId) values(?,?,?,?)";
		PreparedStatement pstmt =preparedStatement(sql);
		
	
		try {
			pstmt.setString(1, user.getName());
			pstmt.setString(2,user.getEmailId());
			pstmt.setString(3, user.getPassword());
			pstmt.setInt(4, user.getGroupDropDown());
			System.out.println(user.getName()+"name in daoimpl");
			System.out.println(user.getEmailId()+"email in daoimpl");
			System.out.println(user.getPassword()+"pass in daoimpl");
			System.out.println(user.getGroupDropDown()+"id in daoImpl");
			pstmt.execute();

		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}
	

}
