package com.yash.ytdms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.yash.ytdms.dao.GroupDAO;
import com.yash.ytdms.domain.Group;
import com.yash.ytdms.domain.User;
import com.yash.ytdms.util.JNDIUtil;

public class GroupDAOImpl extends JNDIUtil implements GroupDAO {

	@Override
	public void save(Group group) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Group> findAll() {
		String sql = "select * from groups";

		List<Group> groups = new ArrayList<Group>();
		PreparedStatement pstmt = preparedStatement(sql);
		ResultSet rs;
		try {
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Group group = new Group();

				group.setId(rs.getInt("id"));
				group.setName(rs.getString("name"));
				group.setStart_date(rs.getDate("start_date"));
				group.setEnd_date(rs.getDate("end_date"));
				group.setStatus(rs.getInt("status"));
				group.setDescription(rs.getString("description"));
				group.setCreatedBy(rs.getString("createdBy"));
				group.setUpdatedBy(rs.getString("updatedBy"));

				groups.add(group);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return groups;
	}

	@Override
	public void add(Group group) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Group group) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<User> findById(int id) {
		String sql = "select * from users where groupId="+id+" and role=3";
		User user;
		List<User> groups = new ArrayList<User>();
		PreparedStatement pstmt = preparedStatement(sql);
		ResultSet rs;
		String name;
		System.out.println("in DAOIMPL----------------");
		try {
			rs = pstmt.executeQuery();
			while (rs.next()) {
				user=new User();
				System.out.println("Resultset found ! ------------------in DAOIMPL");
				Group group = new Group();

				//group.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setId(rs.getInt("id"));
				//group.setStart_date(rs.getDate("start_date"));
				//group.setEnd_date(rs.getDate("end_date"));
				//group.setStatus(rs.getInt("status"));
				//group.setDescription(rs.getString("description"));
				//group.setCreatedBy(rs.getString("createdBy"));
				//group.setUpdatedBy(rs.getString("updatedBy"));

				groups.add(user);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return groups;
	}

	

}