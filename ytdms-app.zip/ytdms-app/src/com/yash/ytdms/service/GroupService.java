package com.yash.ytdms.service;

import java.util.List;

import com.yash.ytdms.domain.Group;

public interface GroupService {
	

	List<Group> listGroups();
	void updateGroup(int id);
	void updateGroup(int idOfGroup, int idOfTrainee);


}