package com.yash.ytdms.test;

import java.util.List;

import com.yash.ytdms.dao.GroupDAO;
import com.yash.ytdms.daoimpl.GroupDAOImpl;
import com.yash.ytdms.domain.Group;

public class GroupDAOList_Operation_Test {
	public static void main(String[] args) {
		GroupDAO groupDAO = new GroupDAOImpl();
		List<Group> groupList= groupDAO.findAll();
		for (Group group : groupList) {
			System.out.println(group);
		}
		
	}

}