package com.yash.ytdms.test;

import com.yash.ytdms.util.JNDIUtil;

public class JNDIUtilTest extends JNDIUtil {

	public static void main(String[] args)  {
		
	
		
	}
}