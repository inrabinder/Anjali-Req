package com.yash.ytdms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.yash.ytdms.dao.GroupDAO;
import com.yash.ytdms.daoimpl.GroupDAOImpl;
import com.yash.ytdms.domain.Group;
import com.yash.ytdms.service.GroupService;
import com.yash.ytdms.util.JNDIUtil;

public class GroupServiceImpl extends JNDIUtil implements GroupService{
	
	
	private GroupDAO groupDAO;
	public GroupServiceImpl() {
		groupDAO = new GroupDAOImpl();
	}
	



	@Override
	public List<Group> listGroups() {
		List<Group> groups = groupDAO.findAll();		
		return groups;
		
	}




	@Override
	public void updateGroup(int idOfGroup,int idOfTrainee) {
		String sql="UPDATE users SET groupId =? WHERE id=?";
		PreparedStatement preparedStatement=preparedStatement(sql);
		try {
			preparedStatement.setInt(1,idOfGroup);
			preparedStatement.setInt(2,idOfTrainee);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}




	@Override
	public void updateGroup(int id) {
		// TODO Auto-generated method stub
		
	}

}