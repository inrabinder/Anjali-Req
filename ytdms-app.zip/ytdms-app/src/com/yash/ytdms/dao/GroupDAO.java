package com.yash.ytdms.dao;

import java.util.List;

import com.yash.ytdms.domain.Group;
import com.yash.ytdms.domain.User;

/**
 * This GroupDAO will perform all the CRUD operations related to Test
 * 
 * @author anjali.baheti
 *
 */

public interface GroupDAO {

	/**
	 * This save method will save the group into groups
	 * 
	 * @param group
	 *            to be saved
	 */

	void save(Group group);

	/**
	 * This findAll method will return the list of all the group available in groups
	 * 
	 * @return
	 */

	List<Group> findAll();

	/**
	 * This add method will add group into groups
	 * 
	 * @param group
	 *            to be deleted
	 */

	void add(Group group);

	/**
	 * This delete method will delete the group from groups
	 * 
	 * @param group to be deleted
	 *            
	 */

	void delete(Group group);

	List<User> findById(int id);
	
	

	
}