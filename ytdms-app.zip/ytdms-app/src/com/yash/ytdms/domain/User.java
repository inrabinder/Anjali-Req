package com.yash.ytdms.domain;

public class User {

	String name;
	int id;
	String emailId;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	String password;
	
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getGroupDropDown() {
		return groupDropDown;
	}
	public void setGroupDropDown(int groupDropDown) {
		this.groupDropDown = groupDropDown;
	}
	private int groupDropDown;
	
	
}
