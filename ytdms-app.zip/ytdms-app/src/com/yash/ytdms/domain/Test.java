package com.yash.ytdms.domain;

/**
 * To save the test data in database. do not modify this. this is only for POC
 * 
 * @author samay.jain
 *
 */
public class Test {
	private int id;
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
