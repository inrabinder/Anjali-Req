package com.yash.ytdms.domain;

import java.util.Date;

/**
 * 
 * @author anjali.baheti
 *
 */

/** 
 * This is to save group into groups
 * 
 * */
public class Group {
	/**
	 * id is the id of the group. id is the primary key and is auto incremented.
	 */
	private int id;
	
	/**
	 * name is the group name. name field is the mandatory field and it cannot be
	 * null.
	 */
	
	private String name;
	
	/**
	 * start_date is the starting date of the group. The group start_date format is
	 * YYYY/MM/DD
	 */
	private Date start_date;
	/**
	 * end_date is the ending date of the group. The group end_date format is
	 * YYYY/MM/DD
	 */
	private Date end_date;
	
	/**
	 * status tells if the group is active or blocked. status of 1 means the
	 * group is active and 0 means blocked
	 */
	private int status;
	
	/**
	 * descriptions holds the overview of the group in terms of technologies
	 * being taught.
	 */
	private String description;
	
	/**
	 * updatedBy tells the name of the person who updated the group.
	 * these rights are only given to the trainer and manager
	 */
	private String updatedBy;
	
	/**
	 * createdBy tells the name of the person who created it. 
	 * group can only be created by a trainer or a manager
	 * 
	 */
	private String createdBy;
	
	/**
	 * 
	 */
	private int userid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	@Override
	public String toString() {
		return "Group [id=" + id + ", name=" + name + ", start_date=" + start_date + ", end_date=" + end_date
				+ ", status=" + status + ", description=" + description + ", updatedBy=" + updatedBy + ", createdBy="
				+ createdBy + ", userid=" + userid + "]";
	}
	
	

}
